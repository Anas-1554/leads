import csv
import re

def split_address():
    with open('Leads.csv', 'r', newline='', encoding='utf-8') as infile:
        reader = csv.reader(infile, quotechar='"', delimiter=',', quoting=csv.QUOTE_ALL, skipinitialspace=True)
        rows = list(reader)

    with open('output.csv', 'w', newline='', encoding='utf-8') as outfile:
        writer = csv.writer(outfile, quotechar='"', quoting=csv.QUOTE_ALL)
        
        # Write the header row
        header = rows[0]
        writer.writerow(header)

        # Process each row
        for row in rows[1:]:  # Skip the header row
            if len(row) >= 5:  # Ensure the row has enough columns
                full_address = row[4]  # The address is in the 5th column (index 4)
                
                # Extract street address, city, state, and zip code using regex
                match = re.search(r'(.*?),\s*(.*?),\s*(\w{2})\s*(\d{5})', full_address)
                
                if match:
                    street = match.group(1).strip()
                    city = match.group(2).strip()
                    state = match.group(3).strip()
                    zip_code = match.group(4).strip()
                    
                    # Update the existing columns if they're present
                    if len(row) >= 12:
                        row[8] = street
                        row[9] = city
                        row[10] = state
                        row[11] = zip_code
                    else:
                        # Add new columns if they don't exist
                        row.extend([street, city, state, zip_code])
                
            # Write the updated row
            writer.writerow(row)

# Run the function
split_address()