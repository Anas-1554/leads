import csv
import re

def parse_address(address):
    # Regular expression to match address components
    pattern = r'^(.*?),\s*(.*?),\s*(\w{2})\s*(\d{5})'
    match = re.match(pattern, address)
    
    if match:
        street, city, state, zipcode = match.groups()
        return street.strip(), city.strip(), state.strip(), zipcode.strip()
    else:
        return address, '', '', ''

def process_csv(input_file, output_file):
    with open(input_file, 'r', newline='', encoding='utf-8') as infile, \
         open(output_file, 'w', newline='', encoding='utf-8') as outfile:
        
        reader = csv.DictReader(infile)
        
        # New fieldnames with parsed address components
        fieldnames = reader.fieldnames + ['Street', 'City', 'State', 'Zipcode']
        
        writer = csv.DictWriter(outfile, fieldnames=fieldnames)
        writer.writeheader()
        
        for row in reader:
            address = row['Address']
            street, city, state, zipcode = parse_address(address)
            
            # Add new fields to the row
            row['Street'] = street
            row['City'] = city
            row['State'] = state
            row['Zipcode'] = zipcode
            
            writer.writerow(row)

# Usage
input_file = 'input.csv'
output_file = 'parsed_output.csv'
process_csv(input_file, output_file)

print(f"Parsed data has been written to {output_file}")