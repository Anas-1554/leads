const { chromium } = require('playwright');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

(async () => {
    console.time("Total Execution Time");
    const browser = await chromium.launch({ headless: false });
    const links = fs.readFileSync('links.txt', 'utf-8').split('\n').filter(Boolean);

    for (const googleUrl of links) {
        console.time("Execution Time");
        const page = await browser.newPage();
        
        // Navigate to Google Maps search page
        await page.goto(googleUrl);
        await page.waitForSelector('[jstcache="3"]');

        // Scroll through the list to load all results
        const scrollable = await page.$('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[1]/div[1]');
        if (!scrollable) {
            console.log('Scrollable element not found.');
            await page.close();
            continue;
        }

        let endOfList = false;
        while (!endOfList) {
            await scrollable.evaluate(node => node.scrollBy(0, 50000));
            endOfList = await page.evaluate(() => document.body.innerText.includes("You've reached the end of the list"));
        }

        // Extract URLs
        const urls = await page.$$eval('a', links => links.map(link => link.href).filter(href => href.startsWith('https://www.google.com/maps/place/')));
        await page.close();

        const scrapePageData = async (url) => {
            for (let attempt = 0; attempt < 3; attempt++) {
                const newPage = await browser.newPage();
                try {
                    await newPage.goto(url);
                    await newPage.waitForSelector('[jstcache="5"]');

                    // Scrape required details
                    const nameElement = await newPage.$('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[1]/h1');
                    let name = nameElement ? await newPage.evaluate(element => element.textContent, nameElement) : '';
                    name = `"${name}"`;

                    const ratingElement = await newPage.$('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/span[1]/span[1]');
                    let rating = ratingElement ? await newPage.evaluate(element => element.textContent, ratingElement) : '';
                    rating = `"${rating}"`;

                    const reviewsElement = await newPage.$('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/span[2]/span/span');
                    let reviews = reviewsElement ? await newPage.evaluate(element => element.textContent, reviewsElement) : '';
                    reviews = reviews.replace(/\(|\)/g, '');
                    reviews = `"${reviews}"`;

                    const categoryElement = await newPage.$('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[2]/span/span/button');
                    let category = categoryElement ? await newPage.evaluate(element => element.textContent, categoryElement) : '';
                    category = `"${category}"`;

                    const addressElement = await newPage.$('button[data-tooltip="Copy address"]');
                    let address = addressElement ? await newPage.evaluate(element => element.textContent, addressElement) : '';
                    address = `"${address}"`;

                    const websiteElement = await newPage.$('a[data-tooltip="Open website"]') || await newPage.$('a[data-tooltip="Open menu link"]');
                    let website = websiteElement ? await newPage.evaluate(element => element.getAttribute('href'), websiteElement) : '';
                    website = `"${website}"`;

                    const phoneElement = await newPage.$('button[data-tooltip="Copy phone number"]');
                    let phone = phoneElement ? await newPage.evaluate(element => element.textContent, phoneElement) : '';
                    phone = `"${phone}"`;

                    url = `"${url}"`;

                    await newPage.close();
                    return { name, rating, reviews, category, address, website, phone, url };
                } catch (error) {
                    console.error(`Error scraping ${url} on attempt ${attempt + 1}:`, error);
                    await newPage.close();
                    if (attempt < 2) {
                        await new Promise(resolve => setTimeout(resolve, 5000)); // 5-second delay before retrying
                    } else {
                        return { name: 'N/A', rating: 'N/A', reviews: 'N/A', category: 'N/A', address: 'N/A', website: 'N/A', phone: 'N/A', url };
                    }
                }
            }
        };

        // Batch processing
        const batchSize = 20; // Adjust batch size based on your system capability
        const results = [];

        for (let i = 0; i < urls.length; i += batchSize) {
            const batchUrls = urls.slice(i, i + batchSize);
            const batchResults = await Promise.all(batchUrls.map(url => scrapePageData(url)));
            results.push(...batchResults);
            console.log(`Batch ${i / batchSize + 1} completed.`);
        }

        // Generate random name for the CSV file
        const nameSheet = `data_${uuidv4()}.csv`;

        // Convert results to CSV format and write to file
        const csvHeader = 'Name,Rating,Reviews,Category,Address,Website,Phone,Url\n';
        const csvRows = results.map(r => `${r.name},${r.rating},${r.reviews},${r.category},${r.address},${r.website},${r.phone},${r.url}`).join('\n');
        fs.writeFileSync(nameSheet, csvHeader + csvRows);

        console.timeEnd("Execution Time");
    }

    await browser.close();
    console.timeEnd("Total Execution Time");
})();
