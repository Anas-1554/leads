import csv
import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

def clean_address(address):
    # Remove extra whitespace and newlines
    return ' '.join(address.split())

def extract_address(text):
    # Regular expression pattern for matching addresses
    address_pattern = r'\b\d{1,5}\s+(?:[A-Za-z0-9.-]+\s){1,5}(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Court|Ct|Way|Parkway|Pkwy|Place|Pl|Circle|Cir|Square|Sq)\b(?:,?\s+(?:[A-Za-z]+\s)?[A-Za-z]+,\s+[A-Z]{2}\s+\d{5}(?:-\d{4})?)?'
    
    matches = re.findall(address_pattern, text, re.IGNORECASE)
    return [clean_address(match) for match in matches]

def scrape_address(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Try to find address in common locations
        potential_address_elements = soup.select('footer, .footer, .contact, #contact, [itemprop="address"]')
        for element in potential_address_elements:
            addresses = extract_address(element.get_text())
            if addresses:
                return addresses[0]  # Return the first found address
        
        # If not found in common locations, search the entire page
        addresses = extract_address(soup.get_text())
        return addresses[0] if addresses else None
        
    except requests.RequestException as e:
        print(f"Error scraping {url}: {str(e)}")
        return None

def process_csv(input_file, output_file):
    with open(input_file, 'r', newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        fieldnames = reader.fieldnames + ['Scraped_Address']
        
        with open(output_file, 'w', newline='', encoding='utf-8') as outfile:
            writer = csv.DictWriter(outfile, fieldnames=fieldnames)
            writer.writeheader()
            
            for row in reader:
                url = row.get('Website', '').strip()
                if url:
                    print(f"Scraping address from: {url}")
                    address = scrape_address(url)
                    row['Scraped_Address'] = address if address else 'Not found'
                else:
                    row['Scraped_Address'] = 'No URL provided'
                
                writer.writerow(row)
                print(f"Address: {row['Scraped_Address']}")
                print("-" * 50)

if __name__ == "__main__":
    input_file = 'list.csv'
    output_file = 'list_with_addresses.csv'
    process_csv(input_file, output_file)
    print(f"Processing complete. Results saved to {output_file}")