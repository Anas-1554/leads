const fs = require('fs');
const csv = require('csv-parser');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const inputFile = 'output.csv';
const outputFile = 'fixed_output.csv';

function cleanUrl(url) {
    try {
        const parsedUrl = new URL(url);
        return `${parsedUrl.protocol}//${parsedUrl.hostname}${parsedUrl.pathname}`;
    } catch (error) {
        console.error(`Invalid URL: ${url}`);
        return url; // Return original URL if it's invalid
    }
}

async function processCSV() {
    const results = [];

    return new Promise((resolve, reject) => {
        fs.createReadStream(inputFile)
            .pipe(csv())
            .on('data', (row) => {
                if (row.Website) {
                    row.Website = cleanUrl(row.Website);
                }
                results.push(row);
            })
            .on('end', () => {
                resolve(results);
            })
            .on('error', (error) => {
                reject(error);
            });
    });
}

async function writeCSV(data) {
    const csvWriter = createCsvWriter({
        path: outputFile,
        header: Object.keys(data[0]).map(key => ({ id: key, title: key }))
    });

    await csvWriter.writeRecords(data);
    console.log(`Clean URLs have been written to ${outputFile}`);
}

async function main() {
    try {
        const cleanedData = await processCSV();
        await writeCSV(cleanedData);
    } catch (error) {
        console.error('An error occurred:', error);
    }
}

main();