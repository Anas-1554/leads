import asyncio
import time
import uuid
import pandas as pd
import re
from urllib.parse import urlparse
from playwright.async_api import async_playwright
import redis
import json

# Initialize Redis client
redis_client = redis.Redis(
  host='profound-grizzly-52597.upstash.io',
  port=6379,
  password='Ac11AAIncDFmMmZiY2NiNDUyNmU0NzY5ODcwYWQ2YTY3NDBiYTdmOHAxNTI1OTc',
  ssl=True
)

async def scrape_page_data(browser, url):
    for attempt in range(3):
        new_page = await browser.new_page()
        try:
            await new_page.goto(url)
            await new_page.wait_for_selector('[jstcache="5"]')

            name_element = await new_page.query_selector('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[1]/h1')
            name = await new_page.evaluate('(element) => element.textContent', name_element) if name_element else ''

            rating_element = await new_page.query_selector('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/span[1]/span[1]')
            rating = await new_page.evaluate('(element) => element.textContent', rating_element) if rating_element else ''

            reviews_element = await new_page.query_selector('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/span[2]/span/span')
            reviews = await new_page.evaluate('(element) => element.textContent', reviews_element) if reviews_element else ''
            reviews = reviews.replace("(", "").replace(")", "")

            category_element = await new_page.query_selector('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[2]/span/span/button')
            category = await new_page.evaluate('(element) => element.textContent', category_element) if category_element else ''

            address_element = await new_page.query_selector('button[data-tooltip="Copy address"]')
            address = await new_page.evaluate('(element) => element.textContent', address_element) if address_element else ''
            address = address.replace('"', '').replace('"', '')  # Remove quotation marks

            website_element = await new_page.query_selector('a[data-tooltip="Open website"], a[data-tooltip="Open menu link"]')
            website = await new_page.evaluate('(element) => element.getAttribute("href")', website_element) if website_element else ''

            phone_element = await new_page.query_selector('button[data-tooltip="Copy phone number"]')
            phone = await new_page.evaluate('(element) => element.textContent', phone_element) if phone_element else ''
            phone = phone.replace('"', '').replace('"', '')  # Remove quotation marks

            await new_page.close()
            return {
                'Name': name, 'Rating': rating, 'Reviews': reviews, 'Category': category,
                'Address': address, 'Website': website, 'Phone': phone, 'Url': url
            }
        except Exception as e:
            print(f"Error scraping {url} on attempt {attempt + 1}: {e}")
            await new_page.close()
            if attempt < 2:
                await asyncio.sleep(5)
    return {
        'Name': 'N/A', 'Rating': 'N/A', 'Reviews': 'N/A', 'Category': 'N/A',
        'Address': 'N/A', 'Website': 'N/A', 'Phone': 'N/A', 'Url': url
    }

def clean_url(url):
    try:
        parsed_url = urlparse(url)
        if not parsed_url.scheme:
            return ''
        return f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}"
    except Exception as e:
        print(f"Invalid URL: {url}")
        return ''

def split_address(address):
    match = re.search(r'(.*?),\s*(.*?),\s*(\w{2})\s*(\d{5})', address)
    if match:
        return {
            'Street': match.group(1).strip(),
            'City': match.group(2).strip(),
            'State': match.group(3).strip(),
            'Zip': match.group(4).strip()
        }
    return {'Street': '', 'City': '', 'State': '', 'Zip': ''}

async def process_and_save_result(result, output_file):
    result['Website'] = clean_url(result['Website'])
    address_parts = split_address(result['Address'])
    result.update(address_parts)
    del result['Address']

    columns_order = ['Name', 'Rating', 'Reviews', 'Category', 'Phone', 'Street', 'City', 'State', 'Zip', 'Website', 'Url']
    df = pd.DataFrame([result])
    df = df[columns_order]

    df.to_csv(output_file, mode='a', header=not pd.io.common.file_exists(output_file), index=False, quoting=1)

async def main():
    start_time = time.time()
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        links = [line.strip() for line in open('links.txt', 'r').readlines() if line.strip()]

        for google_url in links:
            execution_start = time.time()
            
            # Check if this URL has been processed before
            processed_urls = redis_client.get(google_url)
            if processed_urls:
                processed_urls = json.loads(processed_urls)
            else:
                processed_urls = []

            page = await browser.new_page()
            await page.goto(google_url)
            await page.wait_for_selector('[jstcache="3"]')

            scrollable = await page.query_selector('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[1]/div[1]')
            if not scrollable:
                print('Scrollable element not found.')
                await page.close()
                continue

            end_of_list = False
            while not end_of_list:
                await scrollable.evaluate('node => node.scrollBy(0, 50000)')
                end_of_list = await page.evaluate('document.body.innerText.includes("You\'ve reached the end of the list")')

            urls = await page.evaluate('''
                Array.from(document.querySelectorAll('a'))
                     .map(link => link.href)
                     .filter(href => href.startsWith('https://www.google.com/maps/place/'))
            ''')
            await page.close()

            # Filter out already processed URLs
            urls = [url for url in urls if url not in processed_urls]

            output_file = f"{uuid.uuid4()}.csv"
            
            batch_size = 20
            for i in range(0, len(urls), batch_size):
                batch_urls = urls[i:i + batch_size]
                batch_results = await asyncio.gather(*[scrape_page_data(browser, url) for url in batch_urls])
                
                for result in batch_results:
                    await process_and_save_result(result, output_file)
                    processed_urls.append(result['Url'])
                
                # Update Redis with processed URLs
                redis_client.set(google_url, json.dumps(processed_urls))
                
                print(f"Batch {i // batch_size + 1} completed and saved.")

            print(f"Processed data for {google_url} has been written to {output_file}")

            execution_end = time.time()
            print(f"Execution Time for {google_url}: {execution_end - execution_start} seconds")
        
        await browser.close()

    total_end_time = time.time()
    print(f"Total Execution Time: {total_end_time - start_time} seconds")

asyncio.run(main())
