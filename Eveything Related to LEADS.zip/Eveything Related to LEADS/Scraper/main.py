import asyncio
from aiolimiter import AsyncLimiter
from playwright.async_api import async_playwright
import csv
import argparse
from colorama import Fore, Style, init
import time
from tabulate import tabulate
import uuid
import json
import aiosqlite
import sqlite3  # Needed to catch IntegrityError

init(autoreset=True)
DEBUG = False

def debug_print(message, color=Fore.CYAN):
    if DEBUG:
        print(f"{color}{message}{Style.RESET_ALL}")

def debug_table(data):
    if DEBUG:
        headers = ["Field", "Value"]
        table = [[k, v] for k, v in data.items()]
        print(tabulate(table, headers, tablefmt="grid"))

# Simplified scroll function: scroll until "You've reached the end of the list" appears.
async def scroll_and_get_urls(page):
    debug_print("Starting scroll_and_get_urls function", Fore.YELLOW)
    scrollable = await page.query_selector(
        'xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[1]/div[1]'
    )
    if not scrollable:
        debug_print('Scrollable element not found.', Fore.RED)
        return []
    
    end_of_list = False
    while not end_of_list:
        await scrollable.evaluate('node => node.scrollBy(0, 50000)')
        end_of_list = await page.evaluate(
            '() => document.body.innerText.includes("You\'ve reached the end of the list")'
        )
    urls = await page.evaluate('''() => Array.from(document.querySelectorAll('a'))
                                  .map(link => link.href)
                                  .filter(href => href.startsWith('https://www.google.com/maps/place/'))''')
    debug_print(f"Found {len(urls)} URLs after scrolling", Fore.MAGENTA)
    return urls

def clean_website_url(url):
    return url.split('?')[0] if url else ''

def format_value(value):
    if not value:
        return ''
    cleaned = value.strip().strip('"').strip()
    for unwanted in ['î‚°', 'îƒˆ', '', '']:
        cleaned = cleaned.replace(unwanted, '')
    return cleaned

# Scrape a single business page using Chromium.
async def scrape_page_data(browser, url):
    debug_print(f"Scraping URL: {url}", Fore.YELLOW)
    retries = 0
    max_retries = 1
    while retries < max_retries:
        try:
            new_page = await browser.new_page()
            await new_page.goto(url)
            await new_page.wait_for_selector('[jstcache="3"]', timeout=10000)
            debug_print("Page loaded successfully", Fore.GREEN)

            name_element = await new_page.query_selector(
                'xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[1]/h1'
            )
            name = format_value(await name_element.text_content()) if name_element else ''

            phone_element = await new_page.query_selector('button[data-tooltip="Copy phone number"]')
            phone = format_value(await phone_element.text_content()) if phone_element else ''

            rating_element = await new_page.query_selector(
                'xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/span[1]/span[1]'
            )
            rating = format_value(await rating_element.text_content()) if rating_element else ''

            reviews_element = await new_page.query_selector(
                'xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/span[2]/span/span'
            )
            reviews = format_value((await reviews_element.text_content()).replace('(', '').replace(')', '')) if reviews_element else ''

            category_element = await new_page.query_selector(
                'xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[2]/span/span/button'
            )
            category = format_value(await category_element.text_content()) if category_element else ''

            website_element = await new_page.query_selector('a[data-tooltip="Open website"]') or \
                              await new_page.query_selector('a[data-tooltip="Open menu link"]')
            website = format_value(clean_website_url(await website_element.get_attribute('href'))) if website_element else ''

            address_element = await new_page.query_selector('button[data-tooltip="Copy address"]')
            address = format_value(await address_element.text_content()) if address_element else ''

            url = format_value(url)
            result = {
                'name': name,
                'phone': phone,
                'rating': rating,
                'reviews': reviews,
                'category': category,
                'website': website,
                'address': address,
                'url': url
            }
            debug_table(result)
            await new_page.close()
            debug_print("Page scraped successfully", Fore.GREEN)
            return result
        
        except Exception as e:
            debug_print(f"Error scraping {url}: {e}. Retrying ({retries + 1}/{max_retries})...", Fore.RED)
            retries += 1
            await new_page.close()
            await asyncio.sleep(2)
    debug_print(f"Failed to scrape {url} after {max_retries} retries. Skipping...", Fore.RED)
    return None

async def scrape_with_rate_limit(limiter, browser, url):
    async with limiter:
        return await scrape_page_data(browser, url)

async def init_db():
    db = await aiosqlite.connect("businesses.db")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS businesses (
            url TEXT PRIMARY KEY,
            name TEXT,
            phone TEXT,
            rating TEXT,
            reviews TEXT,
            category TEXT,
            website TEXT,
            address TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    await db.commit()
    return db

# Catch duplicates by handling the IntegrityError.
async def store_business_in_sqlite(db, business_data, seen_urls):
    if business_data['url'] in seen_urls:
        print("Entry for same business exist")
        return False
    else:
        seen_urls.add(business_data['url'])
        try:
            await db.execute("""
                INSERT INTO businesses (url, name, phone, rating, reviews, category, website, address)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                business_data['url'],
                business_data['name'],
                business_data['phone'],
                business_data['rating'],
                business_data['reviews'],
                business_data['category'],
                business_data['website'],
                business_data['address']
            ))
            await db.commit()
            return True
        except sqlite3.IntegrityError:
            print("Entry for same business exist")
            return False

async def main():
    parser = argparse.ArgumentParser(description="Google Maps Scraper")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("--headless", type=str, choices=['true', 'false'], default='true',
                        help="Run in headless mode (true/false)")
    args = parser.parse_args()
    global DEBUG
    DEBUG = args.debug

    name_sheet = f'{uuid.uuid4()}.csv'
    try:
        with open('input.txt', 'r') as f:
            google_urls = f.read().splitlines()
    except FileNotFoundError:
        print(f"{Fore.RED}Error: input.txt not found.{Style.RESET_ALL}")
        return

    headless = args.headless.lower() == 'true'
    debug_print("Starting Google Maps Scraper", Fore.YELLOW)
    debug_print(f"Debug mode: {'ON' if DEBUG else 'OFF'}", Fore.YELLOW)
    debug_print(f"Headless mode: {'ON' if headless else 'OFF'}", Fore.YELLOW)
    start_time = time.time()

    rate_limiter = AsyncLimiter(5, 1)
    db = await init_db()
    seen_urls = set()

    async with async_playwright() as p:
        # Launch Firefox for the search page and Chromium for scraping.
        firefox = await p.firefox.launch(headless=headless)
        chrome = await p.chromium.launch(headless=headless)
        unique_businesses = []

        for google_url in google_urls:
            debug_print(f"URL to scrape: {google_url}", Fore.YELLOW)
            firefox_page = await chrome.new_page()
            await firefox_page.goto(google_url)
            await firefox_page.wait_for_selector('[jstcache="3"]')
            debug_print("Initial page loaded in Firefox", Fore.GREEN)
            
            urls = await scroll_and_get_urls(firefox_page)
            await firefox_page.close()

            batch_size = 20
            results = []
            for i in range(0, len(urls), batch_size):
                batch_urls = urls[i:i + batch_size]
                debug_print(f"Processing batch {i // batch_size + 1}", Fore.YELLOW)
                batch_results = await asyncio.gather(*[
                    scrape_with_rate_limit(rate_limiter, chrome, url)
                    for url in batch_urls
                ])
                results.extend([r for r in batch_results if r is not None])
                debug_print(f"Batch {i // batch_size + 1} completed.", Fore.GREEN)
            
            for business in results:
                if business is not None:
                    is_new = await store_business_in_sqlite(db, business, seen_urls)
                    if is_new:
                        unique_businesses.append(business)
            debug_print(f"Finished processing URL: {google_url}", Fore.GREEN)

        with open(name_sheet, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['name', 'phone', 'rating', 'reviews', 'category', 'website', 'address', 'url']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(unique_businesses)

        debug_print(f"Results written to {name_sheet}", Fore.GREEN)
        await firefox.close()
        await chrome.close()
        debug_print("Browsers closed", Fore.GREEN)

    await db.close()
    end_time = time.time()
    debug_print(f"Total execution time: {end_time - start_time:.2f} seconds", Fore.YELLOW)

if __name__ == '__main__':
    asyncio.run(main())
