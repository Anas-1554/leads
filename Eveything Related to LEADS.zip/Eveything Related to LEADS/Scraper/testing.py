import asyncio
from aiolimiter import AsyncLimiter
from playwright.async_api import async_playwright
import csv
import argparse
from colorama import Fore, Style, init
import time
from tabulate import tabulate
import uuid

init(autoreset=True)

DEBUG = False

def debug_print(message, color=Fore.CYAN):
    if DEBUG:
        print(f"{color}{message}{Style.RESET_ALL}")

def debug_table(data):
    if DEBUG:
        headers = ["Field", "Value"]
        table = [[k, v] for k, v in data.items()]
        print(tabulate(table, headers, tablefmt="grid"))

async def scroll_and_get_urls(page):
    debug_print("Starting scroll_and_get_urls function", Fore.YELLOW)
    scrollable = await page.query_selector('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[1]/div[1]')
    if not scrollable:
        debug_print('Scrollable element not found.', Fore.RED)
        return []

    end_of_list = False
    scroll_count = 0
    while not end_of_list:
        await scrollable.evaluate('node => node.scrollBy(0, 50000)')
        scroll_count += 1
        debug_print(f"Scroll {scroll_count} completed", Fore.GREEN)
        end_of_list = await page.evaluate('() => document.body.innerText.includes("You\'ve reached the end of the list")')
        await asyncio.sleep(1)  # Add a small delay to avoid rate limiting

    urls = await page.evaluate('''() => Array.from(document.querySelectorAll('a'))
                                    .map(link => link.href)
                                    .filter(href => href.startsWith('https://www.google.com/maps/place/'))''')
    debug_print(f"Found {len(urls)} URLs", Fore.MAGENTA)
    return urls

def clean_website_url(url):
    """Remove tracking parameters from the website URL."""
    return url.split('?')[0] if url else ''

def format_value(value):
    """Format the value by removing quotes and extra spaces."""
    return value.strip().strip('"').strip()

async def scrape_page_data(browser, url):
    """Scrapes data from a single Google Maps place URL."""
    debug_print(f"Scraping URL: {url}", Fore.YELLOW)
    retries = 0
    max_retries = 1
    while retries < max_retries:
        try:
            new_page = await browser.new_page()
            await new_page.goto(url)
            await new_page.wait_for_selector('[jstcache="3"]', timeout=10000)

            debug_print("Page loaded successfully", Fore.GREEN)

            # Name
            name_element = await new_page.query_selector('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[1]/h1')
            name = await name_element.text_content() if name_element else ''
            name = format_value(name)

            # Phone
            phone_element = await new_page.query_selector('button[data-tooltip="Copy phone number"]')
            phone = await phone_element.text_content() if phone_element else ''
            phone = format_value(phone)

            # Rating
            rating_element = await new_page.query_selector('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/span[1]/span[1]')
            rating = await rating_element.text_content() if rating_element else ''
            rating = format_value(rating)

            # Reviews
            reviews_element = await new_page.query_selector('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/span[2]/span/span')
            reviews = await reviews_element.text_content() if reviews_element else ''
            reviews = format_value(reviews.replace('(', '').replace(')', ''))

            # Category
            category_element = await new_page.query_selector('xpath=/html/body/div[2]/div[3]/div[8]/div[9]/div/div/div[1]/div[2]/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/div[2]/span/span/button')
            category = await category_element.text_content() if category_element else ''
            category = format_value(category)

            # Website
            website_element = await new_page.query_selector('a[data-tooltip="Open website"]') or await new_page.query_selector('a[data-tooltip="Open menu link"]')
            website = await website_element.get_attribute('href') if website_element else ''
            website = clean_website_url(website)
            website = format_value(website)

            # Address
            address_element = await new_page.query_selector('button[data-tooltip="Copy address"]')
            address = await address_element.text_content() if address_element else ''
            address = format_value(address)

            url = format_value(url)

            result = {
                'name': name,
                'phone': phone,
                'rating': rating,
                'reviews': reviews,
                'category': category,
                'website': website,
                'address': address,
                'url': url
            }

            debug_table(result)

            await new_page.close()
            debug_print("Page scraped successfully", Fore.GREEN)
            return result
        
        except Exception as e:
            debug_print(f"Error scraping {url}: {e}. Retrying ({retries + 1}/{max_retries})...", Fore.RED)
            retries += 1
            await new_page.close()
            await asyncio.sleep(2)

    debug_print(f"Failed to scrape {url} after {max_retries} retries. Skipping...", Fore.RED)
    return None

async def main():
    parser = argparse.ArgumentParser(description="Google Maps Scraper")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("--headless", type=str, choices=['true', 'false'], default='true', help="Run in headless mode (true/false)")
    args = parser.parse_args()

    global DEBUG
    DEBUG = args.debug

    # Generate a random UUID for the CSV filename
    name_sheet = f'{uuid.uuid4()}.csv'

    # Read URLs from input.txt
    try:
        with open('input.txt', 'r') as f:
            google_urls = f.read().splitlines()
    except FileNotFoundError:
        print(f"{Fore.RED}Error: input.txt not found.{Style.RESET_ALL}")
        return

    headless = args.headless.lower() == 'true'

    debug_print("Starting Google Maps Scraper", Fore.YELLOW)
    debug_print(f"Debug mode: {'ON' if DEBUG else 'OFF'}", Fore.YELLOW)
    debug_print(f"Headless mode: {'ON' if headless else 'OFF'}", Fore.YELLOW)

    start_time = time.time()

    # Create a rate limiter (e.g., 5 requests per second)
    rate_limiter = AsyncLimiter(5, 1)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=headless)

        for google_url in google_urls:
            debug_print(f"URL to scrape: {google_url}", Fore.YELLOW)
            page = await browser.new_page()
            await page.goto(google_url)
            await page.wait_for_selector('[jstcache="3"]')
            debug_print("Initial page loaded", Fore.GREEN)

            urls = await scroll_and_get_urls(page)

            batch_size = 20
            results = []

            for i in range(0, len(urls), batch_size):
                batch_urls = urls[i:i + batch_size]
                debug_print(f"Processing batch {i // batch_size + 1}", Fore.YELLOW)
                batch_results = await asyncio.gather(*[rate_limiter.acquire(lambda: scrape_page_data(browser, url)) for url in batch_urls])
                results.extend([r for r in batch_results if r is not None])
                debug_print(f'Batch {i // batch_size + 1} completed.', Fore.GREEN)

            with open(name_sheet, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['name', 'phone', 'rating', 'reviews', 'category', 'website', 'address', 'url']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(results)

            debug_print(f"Results written to {name_sheet}", Fore.GREEN)

        await browser.close()
        debug_print("Browser closed", Fore.GREEN)

    end_time = time.time()
    debug_print(f"Total execution time: {end_time - start_time:.2f} seconds", Fore.YELLOW)

if __name__ == '__main__':
    asyncio.run(main())